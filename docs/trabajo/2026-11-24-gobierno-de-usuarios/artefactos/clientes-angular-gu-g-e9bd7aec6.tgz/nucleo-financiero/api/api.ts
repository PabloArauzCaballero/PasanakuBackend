export * from './default.service';
import { DefaultService } from './default.service';
export * from './default.serviceInterface';
export * from './qr.service';
import { QrService } from './qr.service';
export * from './qr.serviceInterface';
export const APIS = [DefaultService, QrService];
