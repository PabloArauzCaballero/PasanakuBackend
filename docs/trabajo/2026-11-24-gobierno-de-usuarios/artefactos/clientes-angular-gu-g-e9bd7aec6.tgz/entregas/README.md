# @

Servicio entregas. Un caso de uso = una operacion, con el codigo CU en el operationId. Los importes viajan como CADENA decimal, nunca como number.  1.1.0 (2026-11-21) · RETIRO DE LA CESION DE TURNOS (D-L2-1, DECISIONES tanda 7: «subasta y cesion de turno: se elimina»). El orden de cobro lo fijan el nivel de puntualidad y el sorteo; un turno no se vende ni se subasta. Las operaciones del mercado (`publicarOferta`, `listarOfertas`, `cancelarOferta`, `comprarOferta`) y de la subasta (`abrirSubastaDeCupo`, `listarSubastasDeCupo`, `consultarSubastaDeCupo`, `pujarEnSubasta`, `cancelarSubastaDeCupo`) quedan RETIRADAS y responden 410 sin efecto (AP-CU130-10 y AP-CU136-09). No llevan `deprecated: true` a proposito: el cliente Dart generado marcaria los metodos y la app, que todavia los llama hasta que L6 retire sus pantallas, no pasaria `dart analyze --fatal-infos`. `consultarOfertaParaPago` sigue respondiendo el 422 AP-CU130-05 del pacto con nucleo-financiero: ya no hay oferta que pagar. Contraccion (regla 98.1.3): se borran del contrato cuando la app movil deje de llamarlas y nucleo-financiero retire su consumidor; la fecha la fija Pablo al mergear esos cambios.  2.0.0 (2026-11-21) · SEG-007, cambio INCOMPATIBLE de seguridad (regla 98.1.3): `EntradaRegistroCuenta` ya no tiene `numeroCifrado`. El servidor cifra el numero de cuenta desde `numeroCuenta`, el mismo del que salen el enmascarado y el hash; un cuerpo que todavia mande `numeroCifrado` recibe 400 (campo no declarado). Sin convivencia a proposito: aceptar el campo es justo la vulnerabilidad. Ningun cliente del monorepo lo enviaba (busqueda en apps/, packages/ y clientes/ sin resultados).  2.1.0 (2026-11-21) · F1.L2.M05 (SEG-005): `anotarRespuestaDesembolso` queda `deprecated` y responde 410 AP-CU28-08. Ninguna persona marca un desembolso como acreditado; lo hara el aviso firmado del proveedor.  2.2.0 (2026-11-21) · F1.L2.M09 y F1.L2.M08: `liquidarEntrega` (POST /entregas) y `ejecutarEntrega` quedan `deprecated` y responden 410 (AP-CU22-10, AP-CU22-11). `EFECTIVO_ORGANIZADOR` sale del enum de `EntradaLiquidacion`: el organizador no es caja (RN-18).

The version of the OpenAPI document: 2.2.0

## Building

To install the required dependencies and to build the typescript sources run:

```console
npm install
npm run build
```

## Publishing

First build the package then run `npm publish dist` (don't forget to specify the `dist` folder!)

## Consuming

Navigate to the folder of your consuming project and run one of next commands.

_published:_

```console
npm install @ --save
```

_without publishing (not recommended):_

```console
npm install PATH_TO_GENERATED_PACKAGE/dist.tgz --save
```

_It's important to take the tgz file, otherwise you'll get trouble with links on windows_

_using `npm link`:_

In PATH_TO_GENERATED_PACKAGE/dist:

```console
npm link
```

In your project:

```console
npm link 
```

__Note for Windows users:__ The Angular CLI has troubles to use linked npm packages.
Please refer to this issue <https://github.com/angular/angular-cli/issues/8284> for a solution / workaround.
Published packages are not effected by this issue.

### General usage

In your Angular project:

```typescript

import { ApplicationConfig } from '@angular/core';
import { provideHttpClient } from '@angular/common/http';
import { provideApi } from '';

export const appConfig: ApplicationConfig = {
    providers: [
        // ...
        provideHttpClient(),
        provideApi()
    ],
};
```

**NOTE**
If you're still using `AppModule` and haven't [migrated](https://angular.dev/reference/migrations/standalone) yet, you can still import an Angular module:
```typescript
import { ApiModule } from '';
```

If different from the generated base path, during app bootstrap, you can provide the base path to your service.

```typescript
import { ApplicationConfig } from '@angular/core';
import { provideHttpClient } from '@angular/common/http';
import { provideApi } from '';

export const appConfig: ApplicationConfig = {
    providers: [
        // ...
        provideHttpClient(),
        provideApi('http://localhost:9999')
    ],
};
```

```typescript
// with a custom configuration
import { ApplicationConfig } from '@angular/core';
import { provideHttpClient } from '@angular/common/http';
import { provideApi } from '';

export const appConfig: ApplicationConfig = {
    providers: [
        // ...
        provideHttpClient(),
        provideApi({
            withCredentials: true,
            username: 'user',
            password: 'password'
        })
    ],
};
```

```typescript
// with factory building a custom configuration
import { ApplicationConfig } from '@angular/core';
import { provideHttpClient } from '@angular/common/http';
import { provideApi, Configuration } from '';

export const appConfig: ApplicationConfig = {
    providers: [
        // ...
        provideHttpClient(),
        {
            provide: Configuration,
            useFactory: (authService: AuthService) => new Configuration({
                    basePath: 'http://localhost:9999',
                    withCredentials: true,
                    username: authService.getUsername(),
                    password: authService.getPassword(),
            }),
            deps: [AuthService],
            multi: false
        }
    ],
};
```

### Using multiple OpenAPI files / APIs

In order to use multiple APIs generated from different OpenAPI files,
you can create an alias name when importing the modules
in order to avoid naming conflicts:

```typescript
import { provideApi as provideUserApi } from 'my-user-api-path';
import { provideApi as provideAdminApi } from 'my-admin-api-path';
import { HttpClientModule } from '@angular/common/http';
import { environment } from '../environments/environment';

export const appConfig: ApplicationConfig = {
    providers: [
        // ...
        provideHttpClient(),
        provideUserApi(environment.basePath),
        provideAdminApi(environment.basePath),
    ],
};
```

### Customizing path parameter encoding

Without further customization, only [path-parameters][parameter-locations-url] of [style][style-values-url] 'simple'
and Dates for format 'date-time' are encoded correctly.

Other styles (e.g. "matrix") are not that easy to encode
and thus are best delegated to other libraries (e.g.: [@honoluluhenk/http-param-expander]).

To implement your own parameter encoding (or call another library),
pass an arrow-function or method-reference to the `encodeParam` property of the Configuration-object
(see [General Usage](#general-usage) above).

Example value for use in your Configuration-Provider:

```typescript
new Configuration({
    encodeParam: (param: Param) => myFancyParamEncoder(param),
})
```

[parameter-locations-url]: https://github.com/OAI/OpenAPI-Specification/blob/main/versions/3.1.0.md#parameter-locations
[style-values-url]: https://github.com/OAI/OpenAPI-Specification/blob/main/versions/3.1.0.md#style-values
[@honoluluhenk/http-param-expander]: https://www.npmjs.com/package/@honoluluhenk/http-param-expander
