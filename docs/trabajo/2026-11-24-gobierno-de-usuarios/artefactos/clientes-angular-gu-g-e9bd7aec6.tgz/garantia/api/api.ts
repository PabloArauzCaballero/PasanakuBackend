export * from './default.service';
import { DefaultService } from './default.service';
export * from './default.serviceInterface';
export * from './respaldo.service';
import { RespaldoService } from './respaldo.service';
export * from './respaldo.serviceInterface';
export const APIS = [DefaultService, RespaldoService];
